% NCCA toolbox
% Version 0.05		13-Oct-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% NCCAOUT Evaluate the output of an NCCA model.
% NCCAOPTIONS Return default options for NCCA model.
% NCCAOPTIMISE Optimise a given NCCA model
% NCCAEMBED Consolidate two data sets using NCCA
% NCCACREATE Create a NCCA model
% NCCAADDDYNAMICS Add a dynamics kernel to the model.
% NCCASEQUENCEOPTIMISE Jointly optimise sequence and observations
% NCCASEQUENCEOBJECTIVEINDEPENDENT Compute objective over
% NCCASEQUENCEOBJECTIVEALL Compute objective over full latent space
% NCCASEQUENCEGRADIENTINDEPENDENT Compute gradients to latent
% NCCASEQUENCEGRADIENTALL Compute gradients to latent
% NCCACOMPUTEVITERBIPATH Computes Viterbi path through a set of latent modes given model with dynamics
% NCCACOMPUTEMODES Compute modes over latent space from NCCA model
% COMPUTETRANST Compute Transitional Probabilities for sequence of modes from ncca model
% COMPUTEOBS Compute observation likelihoods in the ncca model
% NCCAVISUALISE
% POINTMODIFY
% NCCASORTMODES
% VARGRADIENT
% POINTVISUALISE
% VAROBJECTIVE
% NCCAADDDATA
% NCCADISPLAYPRIVATE
% NCCAREMOVEMULTIPLEMODES
% NCCATOOLBOXES Load in the relevant toolboxes for sgplvm.
% NCCADISPLAYLATENT
