function f = nccaSequenceObjectiveIndependent(xvec,model,Xs,varargin)

% NCCASEQUENCEOBJECTIVEINDEPENDENT Compute objective over
%
%	Description:
%	independent subspace of latent space
%
%	F = NCCASEQUENCEOBJECTIVEINDEPENDENT(XVEC, MODEL) Computes objective
%	for a sequence over the independent subspace of latent space for a
%	ncca model
%	 Returns:
%	  F - objective
%	 Arguments:
%	  XVEC - latent positions
%	  MODEL - model generating output observations
%	
%
%	See also
%	FGPLVMSEQUENCEOBJECTIVE


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	nccaSequenceObjectiveIndependent.m SVN version 45
% 	last update 2007-11-03T14:25:06.000000Z

X = [Xs reshape(xvec,size(Xs,1),model.q-size(Xs,2))];
Y = gpOut(model,X);
X = X(:)';

f = fgplvmSequenceObjective(X,model,Y);

return;