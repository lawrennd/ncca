function X = nccaComputeViterbiPath(model_obs_in,model_obs_out,model_dyn,X_mode,Y,balancing,display)

% NCCACOMPUTEVITERBIPATH Computes Viterbi path through a set of latent modes given model with dynamics
%
%	Description:
%
%	X = NCCACOMPUTEVITERBIPATH(MODEL_OBS_IN, MODEL_OBS_OUT, MODEL_DYN,
%	X_MODE, Y, BALANCING, DISPLAY) computes Viterbi path through a set
%	of latent modes given model with dynamics.
%	 Returns:
%	  X - Modes associated with Viterbi path
%	 Arguments:
%	  MODEL_OBS_IN - observation space model onto shared latent space
%	  MODEL_OBS_OUT - observation space generation model
%	  MODEL_DYN - dynamic model
%	  X_MODE - latent space modes
%	  Y - observations
%	  BALANCING - balancing between dynamics and observations (default =
%	   1)
%	  DISPLAY - display progress (default = false)
%	
%
%	See also
%	COMPUTEOBS.M, COMPUTETRANST.M, VITERBI_PATH_LOG_TRANST.M


%	Copyright (c) 2007 Neil D. Lawrence and Carl Henrik Ek
% 	nccaComputeViterbiPath.m SVN version 112
% 	last update 2008-10-12T19:26:29.000000Z

if(nargin<7)
  display = false;
  if(nargin<6)
    balancing = 1;
    if(nargin<5)
      error('To Few Arguments');
    end
  end
end

Obs = computeObs(model_obs_in,model_obs_out,X_mode,Y,display);
Trans = computeTransT(model_dyn,X_mode,false,display);
Trans = Trans.*balancing;
path = viterbi_path_log_transT(zeros(1,size(X_mode{1},1)),Trans,Obs,display);

X = zeros(length(path),size(X_mode{1},2));
for(i = 1:1:length(path))
  X(i,:) = X_mode{i}(path(i),:);
end

return

