function Obs = computeObs(model_g,model_f,X,Y,display)

% COMPUTEOBS Compute observation likelihoods in the ncca model
%
%	Description:
%
%	OBS = COMPUTEOBS(MODEL_G, MODEL_F, X, Y, DISPLAY) Compute
%	Observation likelihood for a set of modes and observations in a ncca
%	model
%	 Returns:
%	  OBS - Model log likelihood Matrix
%	 Arguments:
%	  MODEL_G - model generating observation domain
%	  MODEL_F - model generating corresponding observation domain
%	  X - modes on latent space
%	  Y - observations
%	  DISPLAY - display progress


%	Copyright (c) 2007 Neil D. Lawrence and Carl Henrik Ek
% 	computeObs.m SVN version 112
% 	last update 2008-10-12T19:23:27.000000Z

dim_shared = 1:1:model_g.d;

Obs = zeros(size(X{1},1),size(X,1));
if(display)
  handle_waitbar = waitbar(0,'Computing Observation Probabilities');
end
for(i = 1:1:size(X,1))
  Obs(:,i) = ones(size(Obs,1),1)*gpPointLogLikelihood(model_g,Y(i,:),X{i}(1,dim_shared));
  for(j = 1:1:size(X{i},1))
    [mu varSigma] = gpPosteriorMeanVar(model_f,X{i}(j,:));
    ll = -0.5*sum(log(2*pi)+log(varSigma));
    Obs(j,i) = Obs(j,i)+ll;
  end
  if(display)
    waitbar(i/size(X,1));
  end
end
if(display)
  close(handle_waitbar);
end

return