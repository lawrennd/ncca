
% NCCATOOLBOXES Load in the relevant toolboxes for sgplvm.
%
%	Description:
%	% 	nccaToolboxes.m SVN version 112
% 	last update 2008-10-12T19:30:43.000000Z
importLatest('netlab');
importLatest('prior');
importLatest('optimi');
importLatest('datasets');
importLatest('ndlutil');
importLatest('mocap');
importLatest('mltools');
importLatest('kern');
importLatest('gp');
importLatest('fgplvm');
