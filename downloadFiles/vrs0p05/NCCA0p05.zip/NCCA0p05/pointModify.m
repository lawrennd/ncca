function handle = pointModify(handle,pos,X)

% POINTMODIFY
%
%	Description:
%	


%	Copyright (c) 2008 Carl Henrik Ek and Neil Lawrence
% 	pointModify.m SVN version 114
% 	last update 2008-10-13T12:13:35.000000Z

if(nargin>=3)
  pos = [pos; X];
end

if(size(pos,2)>=3)
  set(handle,'XData',pos(:,1));
  set(handle,'YData',pos(:,2));
  set(handle,'ZData',pos(:,3));
end
if(size(pos,2)==2)
  set(handle,'XData',pos(:,1));
  set(handle,'YData',pos(:,2));
end
if(size(pos,1)==1)
  set(handle,'XData',pos(:,1));
end

return;