function g = nccaSequenceGradientAll(xvec,model,varargin)

% NCCASEQUENCEGRADIENTALL Compute gradients to latent
%
%	Description:
%	sequence over full latent space
%
%	G = NCCASEQUENCEGRADIENTALL(XVEC, MODEL) Compute Gradients for
%	nccaSequenceObjectiveIndependent
%	 Returns:
%	  G - gradient of the indpendent latent coordinates
%	 Arguments:
%	  XVEC - latent positions
%	  MODEL - model generating observations
%	
%
%	See also
%	NCCASEQUENCEGRADIENTINDEPENDENT


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	nccaSequenceGradientAll.m SVN version 45
% 	last update 2007-11-03T14:25:06.000000Z

X = reshape(xvec,size(xvec,2)/model.q,model.q);
Y = gpOut(model,X);
X = X(:)';
g = fgplvmSequenceGradient(X,model,Y);

return