function f = nccaSequenceObjectiveAll(xvec,model,varargin)

% NCCASEQUENCEOBJECTIVEALL Compute objective over full latent space
%
%	Description:
%
%	F = NCCASEQUENCEOBJECTIVEALL(XVEC, MODEL) Computes objective for a
%	sequence over the full latent space for a ncca model
%	 Returns:
%	  F - objective
%	 Arguments:
%	  XVEC - latent positions
%	  MODEL - model generating output observations
%	
%
%	See also
%	FGPLVMSEQUENCEOBJECTIVE


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	nccaSequenceObjectiveAll.m SVN version 45
% 	last update 2007-11-03T14:25:06.000000Z

X = reshape(xvec,size(xvec,2)/model.q,model.q);
Y = gpOut(model,X);
X = X(:)';

f = fgplvmSequenceObjective(X,model,Y);

return;