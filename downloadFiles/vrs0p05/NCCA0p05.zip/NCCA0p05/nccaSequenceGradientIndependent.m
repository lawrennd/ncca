function g = nccaSequenceGradientIndependent(xvec,model,Xs,varargin)

% NCCASEQUENCEGRADIENTINDEPENDENT Compute gradients to latent
%
%	Description:
%	sequence for independent part of ncca embedding
%
%	G = NCCASEQUENCEGRADIENTINDEPENDENT(XVEC, MODEL, XS) Compute
%	Gradients for nccaSequenceObjectiveIndependent
%	 Returns:
%	  G - gradient of the indpendent latent coordinates
%	 Arguments:
%	  XVEC - latent positions
%	  MODEL - model generating observations
%	  XS - shared latent positions
%	
%
%	See also
%	NCCASEQUENCEGRADIENTALL


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	nccaSequenceGradientIndependent.m SVN version 45
% 	last update 2007-11-03T14:25:21.000000Z

X = [Xs reshape(xvec,size(Xs,1),model.q-size(Xs,2))];
Y = gpOut(model,X);
X = X(:)';
g = fgplvmSequenceGradient(X,model,Y);
g = g(prod(size(Xs))+1:1:end);

return