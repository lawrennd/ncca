function f = varObjective(params,model,Xs)

% VAROBJECTIVE
%
%	Description:
%	


%	Copyright (c) 2008 Carl Henrik Ek and Neil Lawrence
% 	varObjective.m SVN version 114
% 	last update 2008-10-13T12:13:35.000000Z

[void f] = gpPosteriorMeanVar(model,[Xs params]);
% For speed skip scaling
%f = 1./sqrt(2*pi*f(:,1));
f = f(:,1);

return