function g = varGradient(params,model,Xs)

% VARGRADIENT
%
%	Description:
%	


%	Copyright (c) 2008 Carl Henrik Ek and Neil Lawrence
% 	varGradient.m SVN version 114
% 	last update 2008-10-13T12:13:35.000000Z

dim_independent = setdiff(1:1:model.q,1:1:size(Xs,2));

[void g] = gpPosteriorGradMeanVar(model,[Xs params]);
g = g(dim_independent,1)';

return