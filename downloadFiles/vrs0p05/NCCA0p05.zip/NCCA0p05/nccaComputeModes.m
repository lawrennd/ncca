function X = nccaComputeModes(model_g,model_f,Y,nr_nn,display,nr_iters)

% NCCACOMPUTEMODES Compute modes over latent space from NCCA model
%
%	Description:
%
%	X = NCCACOMPUTEMODES(MODEL_G, MODEL_F, Y, NR_NN, DISPLAY) X =
%	nccaComputeModes(model_g,model_f,Y,nr_nn,display)
%	 Returns:
%	  X - modes on output latent space
%	 Arguments:
%	  MODEL_G - model mapping onto shared latent space from Y domain
%	  MODEL_F - model mapping from latent space to output domain
%	  Y - input data
%	  NR_NN - number of optimisation initialisations
%	  DISPLAY - display progress (requiers active matlab display)
%	
%
%	See also
%	NULL


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	nccaComputeModes.m SVN version 90
% 	last update 2008-10-03T12:32:21.000000Z


Xs = modelOut(model_g,Y);
dim_independent = setdiff(1:1:model_f.q,1:1:size(Xs,2));;
if(isempty(dim_independent))
  X = Xs;
  return
end

opt_options = optOptions;
if(exist('nr_iters','var'))
  opt_options(14) = nr_iters;
else
  opt_options(14) = 100;
end
opt_options(9) = false;
opt_options(1) = false;

X = cell(size(Y,1),1);
if(display)
  handle_waitbar = waitbar(0,'Optimising');
end
for(i = 1:1:size(Y,1))
  class = nn_class(model_g.y,Xs(i,:),nr_nn,'euclidean');
  for(j = 1:1:length(class))
    X{i}(j,:) = scg('varObjective',model_f.X(class(j),dim_independent),opt_options,'varGradient',model_f,Xs(i,:));
  end
  % append shared dimensions
  X{i} = [repmat(Xs(i,:),size(X{i},1),1) X{i}];
  if(display)
    waitbar(i/size(Y,1));
  end
end
if(display)
  close(handle_waitbar);
end


return
  

