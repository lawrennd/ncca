function options = nccaOptions(approx,kern_options)

% NCCAOPTIONS Return default options for NCCA model.
%
%	Description:
%
%	OPTIONS = NCCAOPTIONS(APPROX, KERN_OPTIONS) options =
%	nccaOptions(approx) returns the default options in a structure for a
%	NCCA model.
%	 Returns:
%	  OPTIONS - option structure
%	 Arguments:
%	  APPROX - approximation type, either 'ftc' (no approximation),
%	   'dtc' (deterministic training conditional), 'fitc' (fully
%	   independent training conditional) or 'pitc' (partially independent
%	   training conditional).
%	  KERN_OPTIONS - kernel options, either 'standard' (rbf compund
%	   kernel) or 'ard' (ARD compund rbf kernel)
%	
%
%	See also
%	NCCACREATE, GPOPTIONS


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	nccaOptions.m SVN version 90
% 	last update 2008-10-03T12:32:21.000000Z

if(nargin<2)
  kern_options = 'ard';
  if(nargin<1)
    approx = 'ftc';
  end
end

options = gpOptions(approx);
options.optimiser = 'scg';
options.scale2var1 = true;

switch kern_options
 case 'ard'
  options.kern = {'cmpnd','rbfard','bias','white'};
 case 'standard'
  options.kern = {'cmpnd','rbf','bias','white'};
 case 'linard'
  options.kern = {'cmpnd','linard','bias','white'};
 otherwise
  error('Unkown Kernel Type');
end
  
return